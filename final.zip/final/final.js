$("#slideshow > div:gt(0)").hide();

setInterval(function() { 
  $('#slideshow > div:first')
    .fadeOut(1000)
    .next()
    .fadeIn(1000)
    .end()
    .appendTo('#slideshow');
},  3000);

$(document).ready(function(){
var total = 3;
var current = 1;

$(".leftarrow").click(function(){

	if (current>1){
		$(".sliderbox2").animate({left:"+=1040"},500)
		current = current-1 //current--
	}

}) //end left

$(".rightarrow").click(function(){

	if (current<total){
		$(".sliderbox2").animate({left:"-=1040"},500)
		current = current+1 //current++
	}
}) //end right

}) //end doc ready